from setuptools import setup, find_packages

setup(
    name="TD1_decentralization",
    version="1.0",
    description=open('README.md').read(),
    author="Mathieu Cowan",
    license='MIT',
    packages=find_packages()
)